package com.example.contactapp

import android.content.Intent
import android.os.Bundle
import android.view.animation.AlphaAnimation
import androidx.appcompat.app.AppCompatActivity
import com.example.contactapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var prefManager: PrefManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefManager = PrefManager.getInstance(this)

        checkLoginStatus()

        val username = prefManager.getUsername()

        binding.txtGreeting.text = "Halo, $username 👋"
        binding.txtUsername.text = username

        // Animasi Fade In
        val fadeIn = AlphaAnimation(0f, 1f).apply { duration = 700 }
        binding.root.startAnimation(fadeIn)

        binding.btnLogout.setOnClickListener {
            prefManager.setLoggedIn(false)
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        binding.btnClear.setOnClickListener {
            prefManager.clear()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    private fun checkLoginStatus() {
        if (!prefManager.isLoggedIn()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}
